const express = require('express')
const path = require('path')
const PORT = process.env.PORT || 5000
const cors = require('cors');
const bodyParser = require('body-parser');
var mongodb = require('mongodb');
const app = express().use(cors()).use(express.json())

const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://manoj10101996:<Password>@appstore.qaabv.mongodb.net/<dbname>?retryWrites=true&w=majority";

app.get('/user', (req, res) => {
  MongoClient.connect(uri, function (err, db) {
    if (err) throw err;
    var dbo = db.db("appointment");
    dbo.collection("user").findOne({}, function (err, result) {
      if (err) throw err;
      res.send(JSON.stringify(result));
      db.close();
    });
  });
});

app.post('/create', (req, res) => {
  MongoClient.connect(uri, function (err, db) {
    if (err) throw err;
    var dbo = db.db("appointment");
    dbo.collection("user").insertOne(req.body, function (err, result) {
      if (err) throw err;
      db.close();
      return res.send(JSON.stringify({
        "status": true,
        "msg": "Success",
        "count": result.insertedCount,
        "id": result.insertedId
      }));
    });
  });
});

app.post('/getAllAppointments', (req, res) => {
  MongoClient.connect(uri, function (err, db) {
    if (err) throw err;
    var dbo = db.db("appointment");
    dbo.collection("user").find({}).sort({ selectedDay: -1 }).toArray(function (err, result) {
      if (err) throw err;
      db.close();
      res.send(JSON.stringify({
        "status": true,
        "msg": "Success",
        "data": result,
      }))
    });
  });
});

app.get('/clearAppointment/:id', (req, res) => {
  MongoClient.connect(uri, function (err, db) {
    if (err) throw err;
    var dbo = db.db("appointment");
    let userData = { _id: new mongodb.ObjectID(req.params.id) }
    dbo.collection("user").deleteOne(userData, function (err, result) {
      if (err) throw err;
      db.close();
      res.send(JSON.stringify({
        "status": true,
        "msg": "Success",
        "data": result.deletedCount,
      }))
    });
  });
})

app.use(express.static(path.join(__dirname, 'public')))
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .get('/', (req, res) => res.render('pages/index'))
  .listen(PORT, () => console.log(`Listening on ${PORT}`))


app.get('/times', (req, res) => res.send(showTimes()))

showTimes = () => {
  let result = '';
  const times = process.env.TIMES || 5;
  for (i = 0; i < times; i++) {
    result += i + ' ';
  }
  return result;
}
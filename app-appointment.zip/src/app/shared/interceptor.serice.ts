import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
declare var $: any;
@Injectable({
    providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {
    constructor(private router: Router) { }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        req = req.clone({
            setHeaders: {
                'Access-Control-Allow-Origin': '*',
                'Authorization': 'Bearer ' + window.localStorage.getItem('token'),
                'Access-Control-Allow-Credentials': '*',
                'supports_credentials': 'true',
                'platform': navigator.platform
            }
        });
        return next.handle(req).pipe(
            tap(evt => {
                if (evt['status'] === 200) {

                }
            }, err => {
                if (err['status'] === 401) {
                    this.router.navigate(['/master/dashboard']);
                    window.localStorage.clear();
                } else if (err['status'] === 500 || err['status'] === 404 || err['status'] === 422) {
                    this.router.navigate(['/master/dashboard']);
                    window.localStorage.clear();
                }
            })
        );
    }
}

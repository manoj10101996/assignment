import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, retry } from 'rxjs/operators';
import { throwError } from 'rxjs';
declare var UIkit: any;
declare var $: any;

@Injectable({
  providedIn: 'root'
})
export class RequiredService {
  public root = 'http://localhost:5000';

  constructor(private http: HttpClient,) {
  }

  public post(url, data) {
    document.cookie = "date=" + new Date();
    return this.http.post(this.root + url, data).pipe(retry(1),
      catchError(this.handleError)
    );
  }

  public get(url, data) {
    return this.http.get(this.root + url, data).pipe(retry(1),
      catchError(this.handleError)
    );
  }

  public delete(url, data) {
    return this.http.delete(this.root + url, data).pipe(retry(1),
      catchError(this.handleError)
    );
  }

  public randomString(length) {
    var result = "";
    var characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }


  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  }

  public notify(term, mode) {
    UIkit.notification({
      message: term,
      status: mode,
      pos: 'top-right',
      timeout: 5000
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { RequiredService } from 'src/app/shared/required.service';
declare var $: any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public morning = [
    {
      slot: 1,
      time: "09:00",
      value: "09:00 AM"
    },
    {
      slot: 2,
      time: "09:10",
      value: "09:10 AM"
    }, {
      slot: 3,
      time: "09:20",
      value: "09:20 AM"
    }, {
      slot: 4,
      time: "09:30",
      value: "09:30 AM"
    }, {
      slot: 5,
      time: "09:40",
      value: "09:40 AM"
    }, {
      slot: 6,
      time: "09:50",
      value: "09:50 AM"
    }, {
      slot: 7,
      time: "10:00",
      value: "10:00 AM"
    }, {
      slot: 8,
      time: "10:10",
      value: "10:10 AM"
    }, {
      slot: 9,
      time: "10:20",
      value: "10:20 AM"
    }, {
      slot: 10,
      time: "10:30",
      value: "10:30 AM"
    }
  ];

  public evening = [
    {
      slot: 1,
      time: "05:00",
      value: "05:00 AM"
    },
    {
      slot: 2,
      time: "05:10",
      value: "05:10 AM"
    }, {
      slot: 3,
      time: "05:20",
      value: "05:20 AM"
    }, {
      slot: 4,
      time: "05:30",
      value: "05:30 AM"
    }, {
      slot: 5,
      time: "05:40",
      value: "05:40 AM"
    }, {
      slot: 6,
      time: "05:50",
      value: "05:50 AM"
    }, {
      slot: 7,
      time: "06:00",
      value: "06:00 AM"
    }, {
      slot: 8,
      time: "06:10",
      value: "06:10 AM"
    }, {
      slot: 9,
      time: "06:20",
      value: "06:20 AM"
    }, {
      slot: 10,
      time: "06:30",
      value: "06:30 AM"
    }
  ];

  public selectedDay: NgbDateStruct;
  public date: { year: number, month: number };
  public stories: any;
  public selectedSlot = '09:00 AM';
  public slotMode = 'morning';
  public register = {
    fullName: "",
    number: "",
    gender: "male",
    date: new Date(),
    issue: '',
    selectedSlot: '',
    slotMode: '',
    dateOfBirth: ''
  };
  public spinner = false;
  public registerForm: FormGroup;
  constructor(private calendar: NgbCalendar, private require: RequiredService, private router: Router) {
  }

  ngOnInit() {
    this.selectedDay = this.calendar.getToday();

    this.registerForm = new FormGroup({
      'fullName': new FormControl(this.register.fullName, [Validators.required]),
      'dateOfBirth': new FormControl(this.register.dateOfBirth, [Validators.required]),
      'number': new FormControl(this.register.number, [Validators.required, Validators.minLength(10)]),
      'gender': new FormControl(this.register.gender),
      'issue': new FormControl(this.register.issue)
    });
  }


  public prepareForm() {
    this.register.fullName = this.registerForm.value['fullName'];
    this.register.number = this.registerForm.value['number'];
    this.register.gender = this.registerForm.value['gender'];
    this.register.date = new Date();
    this.register.dateOfBirth = this.registerForm.value['dateOfBirth'];
    this.register.issue = this.registerForm.value['issue'];
    this.register.slotMode = this.slotMode;
    this.register.selectedSlot = this.selectedSlot;
    this.register['selectedDay'] = this.selectedDay;
    this.spinner = true;
    this.require.post('/create', this.register).subscribe(res => {
      $("#slot").modal('hide')
      if (res['status'] === true) {
        this.spinner = false;
        this.router.navigate(['/master/appointment']);
      } else {
        this.spinner = false;
        this.require.notify('Cannot retrive', 'danger');
      }
    });
  }
}

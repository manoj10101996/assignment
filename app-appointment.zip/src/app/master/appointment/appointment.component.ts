import { Component, OnInit } from '@angular/core';
import { RequiredService } from 'src/app/shared/required.service';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {
  public stories: any;
  public spinner = false;
  constructor(private require: RequiredService) { }

  ngOnInit() {
    this.getUserStories();
  }

  public getUserStories() {
    this.spinner = true;
    let pack = {};
    this.require.post('/getAllAppointments', pack).subscribe(res => {
      this.spinner = false;
      if (res['status'] === true) {
        this.stories = res['data'];
        for (let index = 0; index < this.stories.length; index++) {
          this.stories[index]['age'] = new Date().getFullYear() - new Date(this.stories[index]['dateOfBirth']).getFullYear();
        }
      } else {
        this.require.notify('Cannot retrive', 'danger');
      }
    });
  }


  public clearAppointment(user) {
    this.spinner = true;
    let pack = {
      "id": user._id
    }
    this.require.get('/clearAppointment/' + user._id, pack).subscribe(res => {
      if (res['status'] === true) {
        this.spinner = false;
        this.getUserStories();
      } else {
        this.require.notify('Cannot retrive', 'danger');
      }
    });
  }
  // public createUser() {
  //   let pack = {
  //     "user": "manoj" + Math.random() + Math.random() + Math.random() + Math.random()
  //   }
  //   this.require.post('/create', pack).subscribe(res => {
  //     if (res['status'] === true) {
  //       this.require.notify('Retrive', 'success');
  //     } else {
  //       this.require.notify('Cannot retrive', 'danger');
  //     }
  //   });
  // }
}

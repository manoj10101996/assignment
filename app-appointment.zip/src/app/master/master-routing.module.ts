import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppointmentComponent } from './appointment/appointment.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MasterComponent } from './master.component';


const routes: Routes = [
  {
    path: '', component: MasterComponent
  },
  {
    path: 'dashboard', component: DashboardComponent
  },
  {
    path: 'appointment', component: AppointmentComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterRoutingModule { }

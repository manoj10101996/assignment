import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MasterRoutingModule } from './master-routing.module';
import { MasterComponent } from './master.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { AngularMyDatePickerModule } from 'angular-mydatepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppointmentComponent } from './appointment/appointment.component';


@NgModule({
  declarations: [MasterComponent, DashboardComponent, HeaderComponent, AppointmentComponent],
  imports: [
    CommonModule,
    MasterRoutingModule, FormsModule, ReactiveFormsModule,
    AngularMyDatePickerModule, NgbModule
  ]
})
export class MasterModule { }
